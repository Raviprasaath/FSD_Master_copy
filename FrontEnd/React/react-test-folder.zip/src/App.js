import './App.css';
import ToDo from './components/ToDo/ToDo';
import ToDo2 from './components/ToDo/ToDo2';
import StopWatch from './components/StopWatch/StopWatch';
import Timer from './components/Timer/Timer';
import Counter from './components/Counter/Counter';
import Forms from './components/Forms/Forms'

function App() {
  return (
    <div className="App">
      {/* <ToDo/> */}
      {/* <ToDo2/> */}
      {/* <StopWatch /> */}
      {/* <Timer/> */}
      <Counter/>
      {/* <Forms/> */}
    </div>
  );
}

export default App;
