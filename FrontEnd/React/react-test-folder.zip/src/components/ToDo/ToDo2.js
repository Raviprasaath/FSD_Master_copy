import {useState} from 'react';

const ToDo2 = () => {
    const [input, setInput] = useState("");
    const [toDoList, setToDoList] = useState([]);

function addToDo() {
    setToDoList([input,...toDoList]);
    setInput("");
}

function deleteToDo(currIndex) {
    const filteredData = toDoList.filter((item, index)=>{
        return index !== currIndex;
    });
    setToDoList(filteredData);
}

const cardStyle = {
    backgroundColor: "blue",
    fontSize: "20px",
}


    return (
        <div>
            <h1 style={{textDecoration:"underline"}}>To Do List</h1>
            <input style={{margin:"10px", borderRadius:"5px", height:"20px"}} type="text" value={input} onChange={(e)=>setInput(e.target.value)}/>
            <button style={{color:"Green"}} onClick={addToDo}>Add</button>
            <ul>
                {
                 toDoList.map((item, index)=>(
                     <li style={cardStyle} key={index}>{item} <button style={{background:"red"}} onClick={()=>{deleteToDo(index)}}>Delete</button></li>
                 ))
                }
            </ul>
        </div>
    )
}

export default ToDo2;