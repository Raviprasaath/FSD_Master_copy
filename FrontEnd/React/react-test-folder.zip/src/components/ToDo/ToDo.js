import React, { useState } from 'react'

const ToDo = () => {

    const [input,setInput] = useState("");
    const [lItem,setLItem] = useState([]);

   const addToDoHandler = () => {
        setLItem([...lItem,input]);
        setInput("");
    };

    const deleteHandler = (index) => {
        const newList = lItem.filter((item,i)=> i !== index);
        setLItem(newList);
    }

  return (
    <div>
        <h1>ToDo</h1>
        <input type='text' onChange={((e)=> setInput(e.target.value))} value={input}></input>
        <button onClick={addToDoHandler}>Add ToDo</button>
        <ul>
            {lItem.map((item, index)=> (
                    (<li style={{color:"red"}} key={index}>{item}
                    <button onClick={()=>deleteHandler(index)}> Delete</button>
                    </li>)
            ))
                
            }
        </ul>
    </div>
  )
}

export default ToDo;