import { useEffect } from 'react';
import { useState } from 'react';

function StopWatch() {
    let [elapsedTime, setElapsedTime] = useState(0);
    let [isRunning, setIsRunning] = useState(false);
    const [lapArray, setlapArray] = useState([]);
    

    useEffect(() => {
        let interavalID;
        if (isRunning) {
            interavalID = setInterval(() => {
                setElapsedTime(elapsedTime++);
            }, 1000);
        }

        return () => {
            clearInterval(interavalID);
        }
    }, [isRunning]);


    let ss = elapsedTime % 60;
    let mm = Math.floor((elapsedTime / 60));
    let hh = Math.floor((elapsedTime / 3600));
    let watch = `${(hh < 10) ? "0" : ""}${hh}:${(mm < 10) ? "0" : ""}${mm}:${(ss < 10) ? "0" : ""}${ss}`

    function lapFunction() {
        setlapArray([...lapArray,watch])
    }

    return (
        <div>
            <h1>Stop Watch</h1>
            <div>{watch}</div>
            <button onClick={() => setIsRunning(true)} disabled={isRunning}>Start</button>
            <button onClick={() => setIsRunning(false)} disabled={!isRunning}>Stop</button>
            <button onClick={() => {setElapsedTime(0); setlapArray([]); setIsRunning(false); }} disabled={elapsedTime == 0}>Reset</button>
            <button onClick={lapFunction} disabled={elapsedTime == 0}>Lap</button>
            <ul>
                {
                    lapArray.map((item, index)=>(
                        <li key={index}>{item}</li>
                    ))
                }
            </ul>
        </div>
    );
};

export default StopWatch;