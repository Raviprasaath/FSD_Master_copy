import {useState} from 'react'

export default function Counter(){

    let [counter,setCounter] = useState(0);

    return (
        <div>
            <h1>Counter App</h1>
            <h2>Counter: {counter}</h2>
            <button onClick={()=>{setCounter( (prevCounter)=> prevCounter + 1);}}>Increment</button>
            <button onClick={()=>{setCounter( (prevCounter)=> prevCounter - 1);}}>Decrement</button>
            <br/>
            <button onClick={()=>{setCounter( counter+1);}}>Increment</button>
            <button onClick={()=>{setCounter( counter-1);}}>Decrement</button>
            <br/>
            <button onClick={()=>{setCounter( counter++);}}>Increment</button>
            <button onClick={()=>{setCounter( counter--);}}>Decrement</button>
            <br/>
            <button onClick={()=>{setCounter( ++counter);}}>Increment</button>
            <button onClick={()=>{setCounter( --counter);}}>Decrement</button>
        </div>
    )
}