import {useState} from 'react';

const Forms = () => {

    const [inputs, setInputs] = useState({});



    const handleChange = (event) =>{
        const [key, value] = [event.target.name, event.target.value];
        
        setInputs(inp=>({...inp, [key]:value}));
    }

    const handleSubmit = (event) =>{
        event.preventDefault();
        console.log(inputs);
        alert("Form Submitted");
    }

  return (
    <>
      <form onSubmit={handleSubmit}>
        <h1>Forms</h1>
        <label htmlFor="name">
          Name:
          <input type="text" id="name" onChange={handleChange} name="username" value={inputs.username || ""}></input>
        </label><br/>
        <label htmlFor="email">
          Email:
          <input type="email" id="email" onChange={handleChange} name="email" value={inputs.email || ""}></input>
        </label><br/>
        <label htmlFor="age">
          Age:
          <input type="number" id="age" onChange={handleChange} name='age' value={inputs.age || ""}/>
        </label><br/>
        <input type="submit"/>
      </form>
    </>
  );
};

export default Forms;
