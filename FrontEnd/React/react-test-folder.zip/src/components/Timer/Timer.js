import { useEffect } from "react";
import { useState } from "react";

export default function Timer() {

    const [input, setInput] = useState(10);
    const [timerRunning, setTimerRunning] = useState(false);
    const [countDownNumber, setCountDownNumber] = useState(input);
    // let [countDownNumber, setCountDownNumber] = useState(input);
    

    let intervalId;
    useEffect(() => {
        if(timerRunning){
            intervalId = setInterval(()=>{
                setCountDownNumber((prev)=> prev-1);
                // setCountDownNumber(--countDownNumber);  // this fails when used const in #9
            },1000)
            if(countDownNumber <1){
                clearInterval(intervalId);
                setTimerRunning(false);
            }
        }

        return () => {
            clearInterval(intervalId);
        }

    }, [timerRunning, countDownNumber])

    return (
        <div>
            <h1>Timer</h1>
            <span>Seconds</span>
            <input type="number" min={0} value={input} onChange={(e) => {setInput(e.target.value); setCountDownNumber(e.target.value)}} />
            <button onClick={() => {setTimerRunning(!(timerRunning))}}>{(timerRunning)?"Pause":"Run"}</button>
            <button onClick={()=> {setTimerRunning(false); setCountDownNumber(input)}}>Stop</button>
            <div>{countDownNumber}</div>
            <progress value={countDownNumber} max={input}></progress>
        </div>

    )
}