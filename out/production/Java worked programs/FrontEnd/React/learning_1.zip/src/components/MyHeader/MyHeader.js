import "./MyHeader.css";

function MyHeader() {
  return (
    <>
      <h1> My custom Header</h1>
      Name: <input type="text"></input>
    </>
  );
}

export default MyHeader;