import MyHeader from "./components/MyHeader/MyHeader";
import { useState } from "react";

function App() {
  const [showComp, setShowComp] = useState(0);

  let buttonstatus = false;

  // function btnHandler() {
  //   buttonstatus = !(buttonstatus);
  //   console.log('buttonstatus:', buttonstatus);
  // }
  function btnHandler() {
    setShowComp(()=>{
      console.log('logged 1', showComp);
      return (1);
    });
    
    setShowComp(()=>{
      console.log('logged 2', showComp);
      return (2);
    });
    
    setShowComp(()=>{
      console.log('logged 3', showComp);
      return (3);
    });
    
    setShowComp(()=>{
      console.log('logged 4', showComp);
      return (4);
    });
    
    setShowComp(()=>{
      console.log('logged 5', showComp);
      return (5);
    });
    
  }

  return (
    <div id="myBodyConatiner">
      <div> Hello! This is App</div>
      <button onClick={btnHandler}>Toggle Switch {`${showComp}`}</button>
      {/* {showComp ? <MyHeader /> : ""} */}
    </div>
  );
}

export default App;

//
// (buttonstatus)?(<MyHeader/>):"";
// buttonstatus && (<MyHeader/>)

// js - {}
// html - ()

{
  /* <button onClick={btnHandler}>Hide</button> */
}
{
  /* <button onClick="btnHandler()">Hide</button> */
}
